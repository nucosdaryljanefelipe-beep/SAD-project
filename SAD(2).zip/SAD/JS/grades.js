// Example data for each term
const gradesData = {
  midterm: [
    { course: "IS104", project: 100, exam: 88, activity: 85, quiz: 80, recitation: 88, gpa: 1.75 },
    { course: "PF101", project: 97, exam: 80, activity: 89, quiz: 86, recitation: 89, gpa: 1.75 },
    { course: "NET102", project: 90, exam: 88, activity: 94, quiz: 93, recitation: 90, gpa: 1.50 }
    // add more objects here...
  ],
  finals: [] // No grades yet
};

// Render table rows
function loadGrades(term = "midterm") {
  const tbody = document.getElementById("grades-body");
  tbody.innerHTML = ""; // clear old rows

  const data = gradesData[term];

  if (data.length === 0) {
    // Show "No grades yet" if empty
    const row = document.createElement("tr");
    row.innerHTML = `<td colspan="7" style="text-align:center; font-weight:bold; color:#c82323;">No grades yet</td>`;
    tbody.appendChild(row);
  } else {
    data.forEach(grade => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${grade.course}</td>
        <td>${grade.project}</td>
        <td>${grade.exam}</td>
        <td>${grade.activity}</td>
        <td>${grade.quiz}</td>
        <td>${grade.recitation}</td>
        <td>${grade.gpa}</td>
      `;
      tbody.appendChild(row);
    });
  }
}

// Change data when dropdown is selected
document.getElementById("semester-select").addEventListener("change", function() {
  loadGrades(this.value); // load based on selected option
});

// Load midterm first
document.addEventListener("DOMContentLoaded", () => loadGrades("midterm"));
