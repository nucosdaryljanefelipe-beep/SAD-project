// Timeslots (header row)
const timeSlots = [
  "7:00am", "8:00am", "9:00am", "10:00am", "11:00am",
  "12:00pm", "1:00pm", "2:00pm", "3:00pm", "4:00pm",
  "5:00pm", "6:00pm", "7:00pm", "8:00pm", "9:00pm"
];

// Days (rows)
const days = ["MON", "TUES", "WED", "THUR", "FRI", "SAT"];

// Class schedule data
const scheduleData = [
  { day: "MON", start: 1, length: 7, label: "IS104 | IK604 & IL603" },
  { day: "MON", start: 9, length: 7, label: "PF101 | 1L603 & IK604" },

  { day: "TUES", start: 8, length: 8, label: "CC104 | IK503 & IL604" },

  { day: "WED", start: 6, length: 3, label: "PE3 | SB OG" },
  { day: "WED", start: 9, length: 3, label: "HUM1 | IL503" },

  { day: "THUR", start: 1, length: 7, label: "NET102 | IK504 & IL604" },

  { day: "SAT", start: 1, length: 7, label: "CC105 | IL604 & IK603" }
];

// Build header row
function buildHeader() {
  const thead = document.getElementById("schedule-head");
  thead.innerHTML = ""; // clear first if rebuilding
  const tr = document.createElement("tr");

  // Empty corner cell (Day column)
  const thDay = document.createElement("th");
  thDay.textContent = "Day";
  tr.appendChild(thDay);

  // Time headers
  timeSlots.forEach(slot => {
    const th = document.createElement("th");
    th.textContent = slot;
    tr.appendChild(th);
  });

  thead.appendChild(tr);
}

// Build schedule rows
function buildBody() {
  const tbody = document.getElementById("schedule-body");
  tbody.innerHTML = "";

  days.forEach(day => {
    const tr = document.createElement("tr");

    // Day column
    const tdDay = document.createElement("td");
    tdDay.className = "day-col";
    tdDay.textContent = day;
    tr.appendChild(tdDay);

    let currentSlot = 1;
    while (currentSlot <= timeSlots.length) {
      const classHere = scheduleData.find(
        s => s.day === day && s.start === currentSlot
      );

      if (classHere) {
        const td = document.createElement("td");
        td.colSpan = classHere.length;
        td.innerHTML = `<div class="class-pill">${classHere.label}</div>`;
        tr.appendChild(td);
        currentSlot += classHere.length;
      } else {
        const td = document.createElement("td");
        tr.appendChild(td);
        currentSlot++;
      }
    }

    tbody.appendChild(tr);
  });
}

// Helper: convert "HH:MM" 24h format to "H:MMam/pm"
function formatTime(time) {
  let [hour, minute] = time.split(":").map(Number);
  let period = "am";

  if (hour === 0) {
    hour = 12;
  } else if (hour === 12) {
    period = "pm";
  } else if (hour > 12) {
    hour -= 12;
    period = "pm";
  }

  return `${hour}:${minute.toString().padStart(2, "0")}${period}`;
}

// Initialize schedule
document.addEventListener("DOMContentLoaded", () => {
  buildHeader();
  buildBody();
});

// Handle adding new schedule items
document.getElementById("schedule-form").addEventListener("submit", e => {
  e.preventDefault();

  const day = document.getElementById("day-input").value;
  const startTime = document.getElementById("start-time").value;
  const endTime = document.getElementById("end-time").value;
  const subject = document.getElementById("subject-label").value;
  const room = document.getElementById("room-label").value;

  const startIndex = timeSlots.findIndex(t => t === formatTime(startTime));
  const endIndex = timeSlots.findIndex(t => t === formatTime(endTime));

  if (startIndex === -1 || endIndex === -1 || endIndex <= startIndex) {
    alert("Invalid time range!");
    return;
  }

  const label = `${subject} | ${room}`;

  scheduleData.push({
    day,
    start: startIndex + 1,
    length: endIndex - startIndex + 1,
    label
  });

  buildBody();
  e.target.reset();
});

// Clear all schedule data
document.getElementById("clear-sched").addEventListener("click", () => {
  if (confirm("Are you sure you want to clear all schedules?")) {
    scheduleData.length = 0; // Remove all data
    buildBody(); // Rebuild table (now empty)
  }
});
