// Wait until the page is fully loaded
document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("signupForm");

  form.addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent page reload

    const studentNumber = document.getElementById('studentNumber').value.trim();
    const password = document.getElementById('password').value.trim();
    const message = document.getElementById('signup-message');

    if (!email || !studentNumber || !password) {
      message.textContent = '⚠️ Please fill in all fields.';
      message.style.color = 'red';
      message.classList.remove('hidden');
      return;
    }

    // Save data in localStorage
    localStorage.setItem('registeredStudentNumber', studentNumber);
    localStorage.setItem('registeredPassword', password);

    message.textContent = 'Account created successfully! Redirecting to login...';
    message.style.color = '#F8EDAD';
    message.classList.remove('hidden');

    setTimeout(() => {
      window.location.href = 'studlogin.html';
    }, 1500);
  });
});
