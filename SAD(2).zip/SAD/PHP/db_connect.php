<?php
$host = "localhost";
$user = "root"; // XAMPP default
$pass = "";     // default password (empty)
$db   = "schoolmanagement";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
