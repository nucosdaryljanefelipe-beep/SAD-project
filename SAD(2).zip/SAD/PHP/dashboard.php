<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: SignUp.html"); 
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Dashboard</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Ramabhadra&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  
  <style>
    * {
      font-family: 'Ramabhadra','Inter';
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    html, body {
      width: 100%;
      height: 100%;
      overflow: hidden;
      background-color: #F8EDAD;
    }

    /* Main container*/
    .Celvi {
      display: flex;
      width: 100%;
      height: 100vh;
    }

/* Sidebar */
.sidebar {
  width: 220px;
  background: #F8EDAD;
  color: #ED7C30;
  padding: 20px;
}

.sidebar .logo {
  width: 100px;
  height: 100px;
  flex-shrink: 0;
  margin-bottom: 40px;
  margin-left: 30px;
}

.sidebar ul {
  padding: 0;
}

.sidebar li {
  display: flex;
  align-items: center;
  font-size: 13px;
  width: 100%; 
  margin: 6px;
  margin-top: 20px;
  padding: 12px;
  border-radius: 10px;
  cursor: pointer;
  transition: 
    transform 0.25s ease,
    box-shadow 0.25s ease,
    background 0.25s ease,
    color 0.25s ease;
}

.sidebar li:hover {
  background: rgba(200, 35, 35, 0.15);
  transform: translateX(5px);
  box-shadow: 3px 3px 8px rgba(0,0,0,0.1);
}

.sidebar li:active {
  transform: translateX(2px) scale(0.98);
  box-shadow: 1px 1px 4px rgba(0,0,0,0.15);
}

.sidebar li.active {
  background: rgba(200, 35, 35, 0.25); 
  font-weight: bold;
  color: #c82323;
  box-shadow: inset 4px 0px 0px #c82323, 2px 2px 6px rgba(0,0,0,0.1);
  transform: translateX(5px);
  transition: 
    background 0.4s ease,
    transform 0.3s ease,
    box-shadow 0.4s ease;
}

.sidebar .icon {
  margin-top: 10px;
  margin-right: 10px;
  margin-left: 15px;
  margin-bottom: 10px;
  width: 44px;
  height: 43px;
}

.logout {
  font-weight: bold;
  color: #c82323;
  cursor: pointer;
  display: flex;
  align-items: center;
  text-decoration: none;
  margin-top: 58px;
}

.exit {
  width: 30px;
  height: 30px;
  flex-shrink: 0;
  margin-right: 10px;
  text-decoration: none;
  margin-top: 5px;
  font-weight: bold;
  color: #c82323;
  cursor: pointer;
  display: flex;
  align-items: center;
}
    /* Main content */
    .main-content {
      flex-grow: 1;
      padding: 40px 60px;
      display: flex;
      flex-direction: column;
    }

    h1 {
      color: #c82323;
      font-size: 35px;
    }

    .others {
      background-color: #c82323;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      font-size: 18px;
      width: 55rem;
      height: 34rem;
      border-radius: 20px;
      padding: 50px 50px;
      font-family: 'Inter';
      color: #000000;
      box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    }

    .label {
      margin-bottom: 10px;
      display: inline-block;
      font-size: 33px;
    }

    .section-label {
      margin-top: 20px;
      display: block;
    }

    .teacher-label {
      margin-top: 40px;
      font-size: 30px;
      display: block;
    }

    input[type="textbox"], input {
      padding: 10px 10px;
      width: 40rem;
      height: 50px;
      font-size: 26px;
      border-radius: 8px;
      border: 2px solid #ED7C30;
      background: #fff;
      color: #333;
      margin-top: 6px;
    }
    
  </style>
</head>

<body>
  <div class="Celvi">
    <!-- Sidebar -->
    <aside class="sidebar">
      <div>
        <img src="../qculogo.png" alt="Logo" class="logo">
        <ul>
          <li class="active"><img src="../db.png" alt="Logo" class="icon">Dashboard</li>
          <a href="../department1.html" style="text-decoration: none; color: inherit;">
            <li><img src="../dept.png" alt="Logo" class="icon">Departments</li>
          </a>
          <a href="Announcement.html" style="text-decoration: none; color: inherit;">
            <li><img src="../announce.png" alt="Logo" class="icon">Announcements</li>
          </a>
          <a href="FacultyMem.html" style="text-decoration: none; color: inherit;">
            <li><img src="../fm.png" alt="Logo" class="icon">Faculty Members</li>
          </a>
        </ul>
      </div>
      <!-- ✅ fixed logout link -->
      <a href="../PHP/logout.php" class="logout">
        <img src="../exit.png" alt="Exit" class="exit"> Log Out
      </a>
    </aside>

    <!-- Main content -->
    <div class="main-content">
      <h1>Good Day, <?php echo htmlspecialchars($_SESSION['admin_name']); ?>!</h1>

      <div class="others">
        <span class="label" style="font-size:30px;">Number of Students: 650</span>
        <div class="section-label">
          <span class="label">BSIT:</span>
          <input type="textbox" placeholder="250 students" readonly>
        </div>
        <div class="section-label">
          <span class="label">BSIS:</span>
          <input type="textbox" placeholder="180 students" readonly>
        </div>
        <div class="section-label">
          <span class="label">BSCS:</span>
          <input type="textbox" placeholder="220 students" readonly>
        </div>
        <span class="teacher-label">Number of Teachers: 45</span>
      </div>
    </div>
  </div>
</body>
</html>
