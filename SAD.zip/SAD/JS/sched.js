// Timeslots (header row)
const timeSlots = [
  "7:00am","8:00am","9:00am","10:00am","11:00am",
  "12:00pm","1:00pm","2:00pm","3:00pm","4:00pm","5:00pm","6:00pm", "7:00pm", "8:00pm", "9:00pm"
];

// Days (rows)
const days = ["MON", "TUES", "WED", "THUR", "FRI", "SAT"];

// Class schedule data
const scheduleData = [
  { day: "MON", start: 1, length: 7, label: "IS104 | IK604 & IL603" },
  { day: "MON", start: 9, length: 7, label: "PF101 | 1L603 & IK604" },

  { day: "TUES", start: 8, length: 8, label: "CC104 | IK503 & IL604" },

  { day: "WED", start: 6, length: 3, label: "PE3 | SB OG" },
  { day: "WED", start: 9, length: 3, label: "HUM1 | IL503" },

  { day: "THUR", start: 1, length: 7, label: "NET102 | IK504 & IL604" },

  { day: "SAT", start: 1, length: 7, label: "CC105 | IL604 & IK603" }
];

// Build header row
function buildHeader() {
  const thead = document.getElementById("schedule-head");
  const tr = document.createElement("tr");

  // Empty corner cell (Day column)
  const thDay = document.createElement("th");
  thDay.textContent = "Day";
  tr.appendChild(thDay);

  // Time headers
  timeSlots.forEach(slot => {
    const th = document.createElement("th");
    th.textContent = slot;
    tr.appendChild(th);
  });

  thead.appendChild(tr);
}

// Build schedule rows
function buildBody() {
  const tbody = document.getElementById("schedule-body");
  tbody.innerHTML = "";

  days.forEach(day => {
    const tr = document.createElement("tr");

    // Day column
    const tdDay = document.createElement("td");
    tdDay.className = "day-col";
    tdDay.textContent = day;
    tr.appendChild(tdDay);

    let currentSlot = 1;
    while (currentSlot <= timeSlots.length) {
      const classHere = scheduleData.find(
        s => s.day === day && s.start === currentSlot
      );

      if (classHere) {
        const td = document.createElement("td");
        td.colSpan = classHere.length;
        td.innerHTML = `<div class="class-pill">${classHere.label}</div>`;
        tr.appendChild(td);
        currentSlot += classHere.length;
      } else {
        const td = document.createElement("td");
        tr.appendChild(td);
        currentSlot++;
      }
    }

    tbody.appendChild(tr);
  });
}

// Initialize schedule
document.addEventListener("DOMContentLoaded", () => {
  buildHeader();
  buildBody();
});
