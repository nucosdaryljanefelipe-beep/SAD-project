function signUp() {
  const email = document.getElementById("email").value;
  const studentNumber = document.getElementById("studentNumber").value;
  const password = document.getElementById("password").value;

  if (!email || !studentNumber || !password) {
    alert("Please fill out all fields!");
  } else {
    window.location.href = "dashb.html"; 
  }
}
