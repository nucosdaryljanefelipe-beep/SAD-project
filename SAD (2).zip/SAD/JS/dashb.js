document.addEventListener("DOMContentLoaded", () => {
  const gpaData = {
    midterm: [
      { course: "IS104", percentage: 88, equivalent: "1.75" },
      { course: "PF101", percentage: 88, equivalent: "1.75" },
      { course: "NET102", percentage: 91, equivalent: "1.50" }
    ],
    finals: []
  };

  // Attendance data
  const attendanceData = [
    { subject_code: "IS104", date: "2025-09-29", status: "Absent" },
    { subject_code: "HUM1", date: "2025-10-01", status: "Present" },
    { subject_code: "NET102", date: "2025-10-02", status: "Present" }
  ];

  // Events data
  const eventsData = [
    { start_date: "Oct. 1, 2025", title: "HUM1 - Final Project Deadline" },
    { start_date: "Oct. 6, 2025", title: "Midterm Exam" }
  ];

  // Announcements
  const announcements = [
    { title: "Class Suspension", message: "Classes will be suspended on September 22 due to a typhoon." }
  ];

  // Function to render GPA table
  function renderGPA(period) {
    let gpaTable = document.querySelector("#gpaTable tbody");
    gpaTable.innerHTML = ""; // Clear old rows

    if (gpaData[period].length === 0) {
      gpaTable.innerHTML = `<tr><td colspan="3" style="text-align:center; color:gray;">No grades yet</td></tr>`;
    } else {
      gpaData[period].forEach(row => {
        gpaTable.innerHTML += `<tr>
          <td>${row.course}</td>
          <td>${row.percentage}%</td>
          <td>${row.equivalent}</td>
        </tr>`;
      });
    }
  }

  renderGPA("midterm");

  document.querySelector(".gpa .choices").addEventListener("change", (e) => {
    if (e.target.value.includes("Finals")) {
      renderGPA("finals");
    } else {
      renderGPA("midterm");
    }
  });

  // Attendance
  let attendanceTable = document.querySelector("#attendanceTable tbody");
  attendanceData.forEach(row => {
    let color = row.status === "Present" ? "green" : row.status === "Absent" ? "red" : "orange";
    attendanceTable.innerHTML += `<tr>
      <td>${row.subject_code}</td>
      <td>${row.date}</td>
      <td style="color:${color}; font-weight:bold;">${row.status}</td>
    </tr>`;
  });

  // Events
  let eventsList = document.querySelector("#eventsList");
  eventsData.forEach(ev => {
    eventsList.innerHTML += `<li>${ev.start_date} &nbsp;&nbsp;&nbsp;<strong>${ev.title}</strong></li>`;
  });

  // Announcement
  let annBox = document.querySelector("#announcementBox");
  if (announcements.length > 0) {
    annBox.innerHTML = `<h4>${announcements[0].title}</h4>
                        <p>${announcements[0].message}</p>`;
  }
});
