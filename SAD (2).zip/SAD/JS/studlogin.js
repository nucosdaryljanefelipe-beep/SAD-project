function signUp() {
  const studentNumber = document.getElementById("studentNumber").value;
  const password = document.getElementById("password").value;

  if (!studentNumber || !password) {
    alert("Please fill out all fields!");
  } else {
    window.location.href = "dashb.html"; 
  }
}
