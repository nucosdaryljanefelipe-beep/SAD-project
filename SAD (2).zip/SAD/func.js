const teacherName = "Ms. Santos!";

const weeklySchedules = {
  1: [ 
    { time: "7:00AM - 10:00AM", section: "SBIT-1D", room: "IK604" },
    { time: "11:30AM - 1:30PM", section: "SBIT-1D", room: "IL501" }
  ],
  2: [ 
    { time: "7:00AM - 10:00AM", section: "SBIT-1F", room: "IL502" },
    { time: "11:00AM - 1:30PM", section: "SBIT-1F", room: "IK604" }
  ],
  3: [ 
    { time: "9:00AM - 11:00AM", section: "SBIT-1C", room: "IK101" },
    { time: "1:00PM - 3:00PM", section: "SBIT-2B", room: "IK201" }
  ],
  4: [], 
  5: [ 
    { time: "10:00AM - 12:00PM", section: "SBIT-4B", room: "IK305" }
  ],
  6: []  
};

const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

function setGreeting() {
  const el = document.getElementById('teacherName');
  if (el) el.textContent = teacherName;
}

function makeScheduleRow(entry) {
  const row = document.createElement('div');
  row.className = 'schedule-row';
  row.innerHTML = `<span>${entry.time}</span><span>${entry.section}</span><span>${entry.room}</span>`;
  return row;
}

function updateSchedule(dayIndex) {
  const scheduleList = document.getElementById('scheduleList');
  if (!scheduleList) return;
  
  scheduleList.innerHTML = `
    <div class="schedule-header">
      <span>Time</span>
      <span>Section</span>
      <span>Room</span>
    </div>
  `;

  const classes = weeklySchedules[dayIndex] || [];
  if (classes.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'no-classes';
    empty.textContent = "No classes scheduled.";
    scheduleList.appendChild(empty);
    return;
  }

  classes.forEach(c => scheduleList.appendChild(makeScheduleRow(c)));
}

function setDropdownLabel(dayIndex) {
  const label = document.getElementById('dropdownLabel');
  if (!label) return;
  label.textContent = `${dayNames[dayIndex]} Class`;
}

function buildDropdownMenu(selectedDay) {
  const menu = document.getElementById('dropdownMenu');
  if (!menu) return;
  menu.innerHTML = '';

  for (let i = 1; i <= 6; i++) {
    const item = document.createElement('div');
    item.className = 'dropdown-item';
    if (i === selectedDay) item.classList.add('selected');
    item.textContent = dayNames[i];
    item.dataset.dayIndex = String(i);

    item.addEventListener('click', function () {
      const idx = Number(this.dataset.dayIndex);
      setDropdownLabel(idx);
      updateSchedule(idx);
      Array.from(menu.children).forEach(ch => ch.classList.remove('selected'));
      this.classList.add('selected');
      menu.classList.remove('show');
      document.querySelector('.dropdown-arrow')?.classList.remove('open');
    });

    menu.appendChild(item);
  }
}

document.addEventListener('DOMContentLoaded', function () {
  setGreeting();
  let today = new Date().getDay();
  if (today === 0) today = 1;
  setDropdownLabel(today);
  updateSchedule(today);
  buildDropdownMenu(today);

  const dropdownHeader = document.getElementById('dropdownHeader');
  const dropdownMenu = document.getElementById('dropdownMenu');
  const arrow = document.querySelector('.dropdown-arrow');

  dropdownHeader.addEventListener('click', function () {
    dropdownMenu.classList.toggle('show');
    arrow?.classList.toggle('open');
  });

  document.addEventListener('click', function (e) {
    if (!dropdownHeader.contains(e.target) && !dropdownMenu.contains(e.target)) {
      dropdownMenu.classList.remove('show');
      arrow?.classList.remove('open');
    }
  });
});
